import React from 'react';

function Invitations() {
  return (
    <div className='invitations'>
    </div>
  )
}

export default Invitations;