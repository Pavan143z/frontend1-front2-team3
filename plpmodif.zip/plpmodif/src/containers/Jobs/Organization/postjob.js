import React from 'react'


class PostJob extends React.Component {
    render() {
        return (

            <div className="jumbotron" >



                <div className="container">
                    <div className="row">

                        <div className="form-group" >
                            <h2 ><i>Reach the quality candidates you can’t find anywhere else.  </i></h2>
                            <div className="col-md-6 mt-5 mx-auto">
            <div className="jumbotron text-center">
                                <div >
                                    <input type="text"
                                        className="form-control" placeholder="Company" 
                                    /><br/>
                                </div>
                                <div className="form-group">
                                    <input type="text"
                                        className="form-control " placeholder="Job title"
                                    />
                                </div>
                                <div className="form-group">
                                    <input type="text"
                                        className="form-control " placeholder="Job address or city  "
                                    />
                                    <br />  
                                   <input type="submit" value="Start job post" className="tn btn-primary col-md-8" />
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
                </div>
                <hr />
                <footer className="text-center" font-family="Open Sams">
                 <i>   “The candidate pool on LinkedIn is simply higher caliber. Professionals choose to represent themselves on LinkedIn versus other networks.”
                 </i> <img src={require('../Organization/img1.jpg')} width="150 " />
                    <p align="right ">Julie Leslie,<br />

                        The Howard Group</p>
                </footer>
            </div>



        )
    }
}
export default PostJob;