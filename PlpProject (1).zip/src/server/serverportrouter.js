const express = require("express");
const app = express();
const ServerPortRouter = express.Router();

const ServerPort = require("./app");
const ServerPort2= require("./app1");


ServerPortRouter.route("/Signup").post(function(req, res) {
  const serverport = new ServerPort(req.body);
  serverport
    .save()
    .then(serverport => {
      res.json("User added Successfully");
    })
    .catch(err => {
      res.status(400).send("unable to save to database");
    });
});

ServerPortRouter.route("/register").post(function(req, res) {
    const serverport = new ServerPort2(req.body);
    serverport
      .save()
      .then(serverport => {
        res.json("User added Successfully");
      })
      .catch(err => {
        res.status(400).send("unable to save to database");
      });
  });

// ServerPortRouter.route("/contacts").get(function(req, res) {
//   ServerPort.find(function(err, serverports) {
//     if (err) {
//       console.log(err);
//     } else {
//       res.json(serverports);
//     }
//   });
// });

ServerPortRouter.route("/Signup").get(function(req, res) {
  ServerPort.find(function(err, serverports) {
    if (err) {
      console.log(err);
    } else {
      res.json(serverports);
    }
  });
});

ServerPortRouter.route("/register").get(function(req, res) {
    ServerPort2.find(function(err, serverports) {
      if (err) {
        console.log(err);
      } else {
        res.json(serverports);
      }
    });
  });
module.exports = ServerPortRouter;
