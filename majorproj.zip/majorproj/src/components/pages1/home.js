import React from 'react'

export class Home extends React.Component {
    render(){

    
  return (
    <div>
        <h2>
      I m from home.
      </h2>
    </div>
  )
}
}

export default Home;
