import React from 'react';
// import { Card, Button, CardHeader, CardFooter, CardBody, CardTitle, CardText } from 'reactstrap';
export class  Cardio extends React.Component {
    render(){

   
  return (
    <div>
      
      {/* <div className="card">
  <img className="img" height="100px" width="10%" src={require("../assets/pic2.png")} />
  <div className="container">
    <h4><b>John Doe</b></h4> 
    <p>Architect & Engineer</p> 
  </div>
</div>  */}

<div className="container">
  <h2>Suggested jobs</h2>
  <div className="card-columns">
    <div className="card bg-primary">
      <div className="card-body text-left">
      <div className="card-rows">
        <div className="card">
  <img className="img" height="100px" width="10%" src={require("../assets/pic2.png")} />
  <div className="container">
    <h4><b>John Doe</b></h4> 
    <p>Architect & Engineer</p> 
  </div>
</div></div>
        
      </div>
    </div>
    <div className="card bg-warning">
      <div className="card-body text-center">
        <p className="card-text"><div className="card">
  <img className="img" height="100px" width="10%" src={require("../assets/pic2.png")} />
  <div className="container">
    <h4><b>John Doe</b></h4> 
    <p>Architect & Engineer</p> 
  </div>
</div></p>
      </div>
    </div>
    <div className="card bg-success">
      <div className="card-body text-center">
        <p className="card-text">Some text inside the third card</p>
      </div>
    </div>
    <div className="card bg-danger">
      <div className="card-body text-center">
        <p className="card-text">Some text inside the fourth card</p>
      </div>
    </div>  
    <div className="card bg-light">
      <div className="card-body text-center">
        <p className="card-text">Some text inside the fifth card</p>
      </div>
    </div>
    <div className="card bg-info">
      <div className="card-body text-center">
        <p className="card-text">Some text inside the sixth card</p>
      </div>
    </div>
  </div>
</div>

</div>




    
  )
}
}

export default Cardio;



// import React from 'react'

// export className Cardio extends React.Component {
//     render(){

    
//   return (
//     <div>
//         <h2>
//       I m from card
//       <div className="card">
//       <img className="img" height="100px" width="100%" src={require("../assets/pic2.png")} />
//       <div className="container">
//       <h4><b>John Doe</b></h4> 
//       <p>Architect & Engineer</p>
//       </div>
//       </div>
//       </h2>
//     </div>
//   )
// }
// }

// export default Cardio;
